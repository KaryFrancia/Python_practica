from setuptools import setup

setup(
    name = "Segunda_preentrega+Francia",
    version = "1.0",
    description = "paquete de modelamiento de Clientes de una página de compras",
    author = "Kary Francia",

    packages = ["paquete_ecommerce"],
)